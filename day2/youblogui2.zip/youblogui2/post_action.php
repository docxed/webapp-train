<?php

require_once 'config/db.php';

if (isset($_POST['create'])) {
    // Code here
} else if (isset($_POST['update'])) {
    // Code here
} else if (isset($_GET['delete'])) {
    // Code here
}
